<!-- Modal wallet charge-->
<div id="ajaxModal" class="modal " role="dialog" style="margin-top:100px;">
    <div class="modal-dialog" style="width: 70%;" >

        <!-- Modal content-->
        <div class="modal-content " style="border: 1px solid #00A8B3;overflow-x:scroll;" >
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal">&times;</button>
                مابینو
            </div>
            <div class="modal-body">

            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-default" data-dismiss="modal">بستن</button>
            </div>
        </div>

    </div>
</div>

<!--end Modal wallet charge-->